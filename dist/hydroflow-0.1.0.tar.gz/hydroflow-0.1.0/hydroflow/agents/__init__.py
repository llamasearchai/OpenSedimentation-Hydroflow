"""OpenAI agents integration for HydroFlow."""


